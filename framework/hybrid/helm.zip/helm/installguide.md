# intall guide
## basic installs
### install kubectl:  
linux: https://kubernetes.io/docs/tasks/tools/install-kubectl-linux/
windows: https://kubernetes.io/docs/tasks/tools/install-kubectl-windows/
## Step1: kubernetes
First check is there is a cluster running with **kubectl cluster-info**. if not:
### Linux:
<pre><code>curl -sfL https://get.k3s.io | sh - 
</code></pre>
### Windows:
todo: look into k3d or alternative for windows
## Step 2: pull HELM chart
pull the helm repo
TODO link to helm repo
## Step 3: deploy HELM chart
<pre><code>helm upgrade --install {name} .\helm\ --values .\helm\values.yaml --set imagePullSecret.username={username} --set imagePullSecret.password={password} --set Framework.APPINSIGHTS_INSTRUMENTATIONKEY={appinsights_instrumentationkey} --set Framework.InvictusDashboardConnectionString={InvictusDashboardConnectionString}
</code></pre>
replace the bracketed values with the wanted ones
| Variable                         | Description                      |
|----------------------------------|----------------------------------|
| {name}                           | wanted name of the helm chart    |
| {username}                       | username given by codit products |
| {password}                       | password given by codit products |
| {appinsights_instrumentationkey} | the appinstights key             |
| {InvictusDashboardConnectionString} | dashboard connection string   |


### optional settings
In the README.md you can find all the optional parameters.
Some interesting are:
<pre><code>--set existingSQLConnectionString={connectionstring}</code></pre>
<pre><code>--set PubSub.RmqConnectionString={amqpconnectionstring}</code></pre>
If you set these the corresponding resource will not be used but the one you gave will.
## Step 4: enbale arc
todo note powershell script

